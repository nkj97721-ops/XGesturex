import sys

path = "app/src/main/java/com/slideindex/app/freezer/FreezerOperations.kt"
anchor = (
    "        if (FreezerCloneKey.isClone(app.packageName)) {\n"
    "            // 分身：直接在对应用户里启动，不经过系统「选主应用还是分身」的弹窗。\n"
    "            return@withContext FreezerCloneSupport.launchClone(app.packageName)\n"
    "        }\n"
)
extra = (
    "        // 主应用：全屏启动时也走 shell 指定用户启动，避免系统弹出「主应用 / 分身」选择框。\n"
    "        if (fullscreen && hasShellAccess() && FreezerCloneSupport.launchMain(app.packageName)) {\n"
    "            return@withContext true\n"
    "        }\n"
)
with open(path, encoding="utf-8", newline="") as f:
    raw = f.read()
crlf = "\r\n" in raw
text = raw.replace("\r\n", "\n")
if text.count(anchor) != 1:
    print(f"锚点出现 {text.count(anchor)} 次 期望 1 次 一个文件都没改")
    sys.exit(1)
if "FreezerCloneSupport.launchMain" in text:
    print("已经打过这个补丁 跳过")
    sys.exit(0)
text = text.replace(anchor, anchor + extra)
if crlf:
    text = text.replace("\n", "\r\n")
with open(path, "w", encoding="utf-8", newline="") as f:
    f.write(text)
print("补丁完成")
