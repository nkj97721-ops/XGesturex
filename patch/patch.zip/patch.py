import re
import sys

BASE = "app/src/main/java/com/slideindex/app/freezer/"
errors = []
outputs = {}


def load(path):
    with open(path, encoding="utf-8", newline="") as f:
        raw = f.read()
    crlf = "\r\n" in raw
    return raw.replace("\r\n", "\n"), crlf


def save(path, text, crlf):
    if crlf:
        text = text.replace("\n", "\r\n")
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def apply(path, edits):
    try:
        text, crlf = load(path)
    except OSError as e:
        errors.append(f"{path}: 读取失败 {e}")
        return
    for old, new, count in edits:
        n = text.count(old)
        if n != count:
            errors.append(f"{path}: 锚点出现 {n} 次 期望 {count} 次\n--- 锚点开头 ---\n{old[:160]}")
            continue
        text = text.replace(old, new)
    outputs[path] = (text, crlf)


# ---------------------------------------------------------------- FreezerPrivilegedOps
ops = BASE + "FreezerPrivilegedOps.kt"
apply(ops, [
    (
        "    fun isProtectedPackage(context: Context, packageName: String): Boolean {\n"
        "        if (packageName == BuildConfig.APPLICATION_ID) return true\n",
        "    fun isProtectedPackage(context: Context, rawPackageName: String): Boolean {\n"
        "        val packageName = FreezerCloneKey.basePackage(rawPackageName)\n"
        "        if (packageName == BuildConfig.APPLICATION_ID) return true\n",
        1,
    ),
    (
        "    private fun appFlags(context: Context, packageName: String): Pair<Boolean, Boolean>? = runCatching {\n"
        "        val info = context.packageManager.getApplicationInfo(packageName, APP_INFO_FLAGS)\n"
        "        info.enabled to ((info.flags and ApplicationInfo.FLAG_SUSPENDED) != 0)\n"
        "    }.getOrNull()\n",
        "    /** 分身（包名#用户ID）经 Shizuku 查指定用户；普通应用走原来的本地查询。 */\n"
        "    private fun appFlags(context: Context, packageName: String): Pair<Boolean, Boolean>? = runCatching {\n"
        "        val cloneUserId = FreezerCloneKey.userIdOf(packageName)\n"
        "        val info: ApplicationInfo = (\n"
        "            if (cloneUserId == null) {\n"
        "                context.packageManager.getApplicationInfo(packageName, APP_INFO_FLAGS)\n"
        "            } else {\n"
        "                appInfoAsUser(FreezerCloneKey.basePackage(packageName), cloneUserId)\n"
        "            }\n"
        "            ) ?: return@runCatching null\n"
        "        info.enabled to ((info.flags and ApplicationInfo.FLAG_SUSPENDED) != 0)\n"
        "    }.getOrNull()\n"
        "\n"
        "    /** 经 Shizuku 调 IPackageManager.getApplicationInfo(包名, flags, 用户)。 */\n"
        "    private fun appInfoAsUser(packageName: String, userId: Int): ApplicationInfo? = runCatching {\n"
        "        val packageManager = bindShizukuPackageManager()\n"
        "        val method = packageManager.javaClass.methods.first {\n"
        "            it.name == \"getApplicationInfo\" && it.parameterTypes.size == 3\n"
        "        }\n"
        "        // Android 13 起 flags 是 long，之前是 int。\n"
        "        val flagsArg: Any = if (method.parameterTypes[1] == java.lang.Long.TYPE) {\n"
        "            APP_INFO_FLAGS.toLong()\n"
        "        } else {\n"
        "            APP_INFO_FLAGS\n"
        "        }\n"
        "        method.invoke(packageManager, packageName, flagsArg, userId) as? ApplicationInfo\n"
        "    }.getOrNull()\n",
        1,
    ),
    (
        "            TaskManagerUtil.forceStopPackage(packageName)\n",
        "            if (!FreezerCloneKey.isClone(packageName)) TaskManagerUtil.forceStopPackage(packageName)\n",
        2,
    ),
    (
        '                "am force-stop --user $userId $packageName",\n',
        '                "am force-stop --user $userId ${FreezerCloneKey.basePackage(packageName)}",\n',
        2,
    ),
    (
        "        val userId = resolveUserId(useRoot)\n",
        "        val userId = FreezerCloneKey.userIdOf(packageName) ?: resolveUserId(useRoot)\n",
        2,
    ),
    (
        "    private fun appExists(context: Context, packageName: String): Boolean = runCatching {\n"
        "        context.packageManager.getApplicationInfo(packageName, APP_INFO_FLAGS)\n"
        "        true\n"
        "    }.getOrDefault(false)\n",
        "    private fun appExists(context: Context, packageName: String): Boolean =\n"
        "        appFlags(context, packageName) != null\n",
        1,
    ),
    (
        "        val packages = arrayOf(packageName)\n",
        "        val packages = arrayOf(FreezerCloneKey.basePackage(packageName))\n",
        1,
    ),
    (
        "        ).invoke(packageManager, packageName, userId) as Int\n",
        "        ).invoke(packageManager, FreezerCloneKey.basePackage(packageName), userId) as Int\n",
        1,
    ),
    (
        "            ).invoke(\n"
        "                packageManager,\n"
        "                packageName,\n"
        "                newState,\n",
        "            ).invoke(\n"
        "                packageManager,\n"
        "                FreezerCloneKey.basePackage(packageName),\n"
        "                newState,\n",
        1,
    ),
])

# pm suspend / pm enable 等 shell 命令里的包名换成真正的包名（共 9 处）
if ops in outputs:
    text, crlf = outputs[ops]
    text, n = re.subn(
        r'(add\("pm \$verb[^"\n]*?)\$packageName"\)',
        lambda m: m.group(1) + '${FreezerCloneKey.basePackage(packageName)}")',
        text,
    )
    if n != 9:
        errors.append(f"{ops}: shell 命令里的包名应替换 9 处 实际 {n} 处")
    outputs[ops] = (text, crlf)

# ---------------------------------------------------------------- FreezerOperations
apply(BASE + "FreezerOperations.kt", [
    (
        "        withContext(Dispatchers.Main) {\n"
        "            launchApp(context, app, settings, appRepository, fullscreen)\n"
        "        }\n"
        "    }\n",
        "        if (FreezerCloneKey.isClone(app.packageName)) {\n"
        "            // 分身：直接在对应用户里启动，不经过系统「选主应用还是分身」的弹窗。\n"
        "            return@withContext FreezerCloneSupport.launchClone(app.packageName)\n"
        "        }\n"
        "        withContext(Dispatchers.Main) {\n"
        "            launchApp(context, app, settings, appRepository, fullscreen)\n"
        "        }\n"
        "    }\n",
        1,
    ),
    (
        "        for (pkg in packages) {\n"
        "            val state = stateOf(context, pkg)\n"
        "            val decision = FreezerIntentResolution.decide(\n",
        "        for (pkg in packages) {\n"
        "            // 白名单里的应用：批量收回时跳过。\n"
        "            if (FreezerPinStore.isWhitelisted(context, pkg)) continue\n"
        "            val state = stateOf(context, pkg)\n"
        "            val decision = FreezerIntentResolution.decide(\n",
        1,
    ),
    (
        "            if (stateOf(context, pkg).isActive && setPaused(context, pkg, paused = true)) count++\n",
        "            if (FreezerPinStore.isWhitelisted(context, pkg)) continue\n"
        "            if (stateOf(context, pkg).isActive && setPaused(context, pkg, paused = true)) count++\n",
        1,
    ),
])

# ---------------------------------------------------------------- FreezerGridUi
grid = BASE + "FreezerGridUi.kt"
apply(grid, [
    (
        "    val filteredApps = remember(memberApps, searchQuery) {\n"
        "        val query = searchQuery.trim().lowercase()\n"
        "        memberApps.filter { app ->\n"
        "            query.isBlank() ||\n"
        "                app.label.contains(query, ignoreCase = true) ||\n"
        "                app.packageName.contains(query, ignoreCase = true) ||\n"
        "                app.pinyinKey.contains(query)\n"
        "        }\n"
        "    }\n",
        "    val filteredApps = remember(memberApps, searchQuery, freezeStateRevision) {\n"
        "        val query = searchQuery.trim().lowercase()\n"
        "        memberApps.filter { app ->\n"
        "            query.isBlank() ||\n"
        "                app.label.contains(query, ignoreCase = true) ||\n"
        "                app.packageName.contains(query, ignoreCase = true) ||\n"
        "                app.pinyinKey.contains(query)\n"
        "        }.sortedByDescending { app -> FreezerPinStore.isPinned(context, app.packageName) }\n"
        "    }\n",
        1,
    ),
    (
        "PickerAppIconBitmap.peek(app.packageName)",
        "PickerAppIconBitmap.peek(FreezerCloneKey.basePackage(app.packageName))",
        2,
    ),
    (
        "PickerAppIconBitmap.load(context, app.packageName)",
        "PickerAppIconBitmap.load(context, FreezerCloneKey.basePackage(app.packageName))",
        2,
    ),
    (
        "    val onRestoreAndRemoveFromList: () -> Unit,\n)\n",
        "    val onRestoreAndRemoveFromList: () -> Unit,\n"
        "    val onTogglePin: () -> Unit,\n"
        "    val onToggleWhitelist: () -> Unit,\n)\n",
        1,
    ),
    (
        "                onAddToHome = {\n"
        "                    if (!FreezerAppShortcutHelper.requestPinAppShortcut(context, app)) {\n"
        "                        FreezerAppShortcutHelper.showPinShortcutFailedToast(context)\n"
        "                    }\n"
        "                    dismissMenu()\n"
        "                },\n",
        "                onTogglePin = {\n"
        "                    FreezerPinStore.setPinned(\n"
        "                        context,\n"
        "                        app.packageName,\n"
        "                        !FreezerPinStore.isPinned(context, app.packageName),\n"
        "                    )\n"
        "                    onFreezeStateRevisionBump()\n"
        "                    dismissMenu()\n"
        "                },\n"
        "                onToggleWhitelist = {\n"
        "                    FreezerPinStore.setWhitelisted(\n"
        "                        context,\n"
        "                        app.packageName,\n"
        "                        !FreezerPinStore.isWhitelisted(context, app.packageName),\n"
        "                    )\n"
        "                    onFreezeStateRevisionBump()\n"
        "                    dismissMenu()\n"
        "                },\n"
        "                onAddToHome = {\n"
        "                    if (!FreezerCloneKey.isClone(app.packageName) &&\n"
        "                        !FreezerAppShortcutHelper.requestPinAppShortcut(context, app)\n"
        "                    ) {\n"
        "                        FreezerAppShortcutHelper.showPinShortcutFailedToast(context)\n"
        "                    }\n"
        "                    dismissMenu()\n"
        "                },\n",
        1,
    ),
    (
        "    val menuEntry = DropdownEntry(\n"
        "        items = buildList {\n"
        "            add(DropdownItem(text = launchFreeWindowLabel, onClick = callbacks.onLaunchFreeWindow))\n"
        "            add(DropdownItem(text = freezeLabel, onClick = callbacks.onToggleFrozen))\n"
        "            add(DropdownItem(text = pauseLabel, onClick = callbacks.onTogglePaused))\n"
        "            add(DropdownItem(text = addToHomeLabel, onClick = callbacks.onAddToHome))\n",
        "    val dialogContext = LocalContext.current\n"
        "    val pinLabel = if (FreezerPinStore.isPinned(dialogContext, app.packageName)) \"取消置顶\" else \"置顶\"\n"
        "    val whitelistLabel = if (FreezerPinStore.isWhitelisted(dialogContext, app.packageName)) {\n"
        "        \"移出白名单\"\n"
        "    } else {\n"
        "        \"加入白名单\"\n"
        "    }\n"
        "    val menuEntry = DropdownEntry(\n"
        "        items = buildList {\n"
        "            add(DropdownItem(text = launchFreeWindowLabel, onClick = callbacks.onLaunchFreeWindow))\n"
        "            add(DropdownItem(text = freezeLabel, onClick = callbacks.onToggleFrozen))\n"
        "            add(DropdownItem(text = pauseLabel, onClick = callbacks.onTogglePaused))\n"
        "            add(DropdownItem(text = pinLabel, onClick = callbacks.onTogglePin))\n"
        "            add(DropdownItem(text = whitelistLabel, onClick = callbacks.onToggleWhitelist))\n"
        "            if (!FreezerCloneKey.isClone(app.packageName)) {\n"
        "                add(DropdownItem(text = addToHomeLabel, onClick = callbacks.onAddToHome))\n"
        "            }\n",
        1,
    ),
    (
        "    val menuItems = buildList {\n"
        "        add(launchFreeWindowLabel to callbacks.onLaunchFreeWindow)\n"
        "        add(freezeLabel to callbacks.onToggleFrozen)\n"
        "        add(pauseLabel to callbacks.onTogglePaused)\n"
        "        add(addToHomeLabel to callbacks.onAddToHome)\n",
        "    val pinLabel = if (FreezerPinStore.isPinned(context, app.packageName)) \"取消置顶\" else \"置顶\"\n"
        "    val whitelistLabel = if (FreezerPinStore.isWhitelisted(context, app.packageName)) {\n"
        "        \"移出白名单\"\n"
        "    } else {\n"
        "        \"加入白名单\"\n"
        "    }\n"
        "    val menuItems = buildList {\n"
        "        add(launchFreeWindowLabel to callbacks.onLaunchFreeWindow)\n"
        "        add(freezeLabel to callbacks.onToggleFrozen)\n"
        "        add(pauseLabel to callbacks.onTogglePaused)\n"
        "        add(pinLabel to callbacks.onTogglePin)\n"
        "        add(whitelistLabel to callbacks.onToggleWhitelist)\n"
        "        if (!FreezerCloneKey.isClone(app.packageName)) add(addToHomeLabel to callbacks.onAddToHome)\n",
        1,
    ),
    (
        "        Text(\n"
        "            text = app.label,\n"
        "            style = MaterialTheme.typography.bodyMedium,\n",
        "        Text(\n"
        "            text = FreezerPinStore.marker(context, app.packageName) + app.label,\n"
        "            style = MaterialTheme.typography.bodyMedium,\n",
        1,
    ),
])

# ---------------------------------------------------------------- FreezerPanelContent
apply(BASE + "FreezerPanelContent.kt", [
    (
        "        memberApps = appRepository.resolveFreezerMembers(settings.freezerAppPackages)\n",
        "        memberApps = FreezerCloneSupport.resolveMembers(appRepository, settings.freezerAppPackages)\n",
        1,
    ),
    (
        "    LaunchedEffect(settings.freezerAppPackages) {\n"
        "        if (settings.freezerAppPackages.isEmpty()) {\n",
        "    // 打开面板时把分身里的应用自动加进列表（每个分身只加一次）。\n"
        "    LaunchedEffect(Unit) {\n"
        "        FreezerCloneSupport.syncCloneMembers(context, settingsRepository)\n"
        "    }\n"
        "\n"
        "    LaunchedEffect(settings.freezerAppPackages) {\n"
        "        if (settings.freezerAppPackages.isEmpty()) {\n",
        1,
    ),
])

# ---------------------------------------------------------------- 共存：debug 包名加后缀（失败只警告）
gradle = "app/build.gradle.kts"
warn = []
try:
    gtext, gcrlf = load(gradle)
    if "applicationIdSuffix" in gtext:
        warn.append("build.gradle.kts 里已有 applicationIdSuffix 未改动")
    else:
        m = re.search(r"(buildTypes\s*\{.*?\n(\s*)debug\s*\{\n)", gtext, re.S)
        if m:
            insert = m.group(1) + m.group(2) + "    applicationIdSuffix = \".x\"\n"
            gtext = gtext[: m.start(1)] + insert + gtext[m.end(1):]
            outputs[gradle] = (gtext, gcrlf)
        else:
            warn.append("没找到 debug 构建类型 包名后缀没加")
except OSError as e:
    warn.append(f"读取 build.gradle.kts 失败 {e}")

if errors:
    print("补丁失败 一个文件都没改：")
    for e in errors:
        print("-", e)
    sys.exit(1)

for path, (text, crlf) in outputs.items():
    save(path, text, crlf)
    print("已修改", path)
for w in warn:
    print("提示:", w)
print("补丁完成")
