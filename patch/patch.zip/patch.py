import sys

BASE = "app/src/main/java/com/slideindex/app/freezer/"


def load(path):
    with open(path, encoding="utf-8", newline="") as f:
        raw = f.read()
    return raw.replace("\r\n", "\n"), "\r\n" in raw


def save(path, text, crlf):
    if crlf:
        text = text.replace("\n", "\r\n")
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def patch(path, marker, edits):
    """marker 已在文件里说明打过了 跳过；锚点对不上就报错并且不改。"""
    text, crlf = load(path)
    if marker in text:
        print("已打过 跳过:", path, marker)
        return True
    for old, new, count in edits:
        n = text.count(old)
        if n != count:
            print(f"补丁失败 {path}: 锚点出现 {n} 次 期望 {count} 次\n{old[:160]}")
            return False
        text = text.replace(old, new)
    save(path, text, crlf)
    print("已修改", path)
    return True


ok = True

# ---- 1) 主应用全屏启动也走 shell 指定用户启动 避免系统弹「主应用 / 分身」选择框
ok &= patch(
    BASE + "FreezerOperations.kt",
    "FreezerCloneSupport.launchMain",
    [(
        "        if (FreezerCloneKey.isClone(app.packageName)) {\n"
        "            // 分身：直接在对应用户里启动，不经过系统「选主应用还是分身」的弹窗。\n"
        "            return@withContext FreezerCloneSupport.launchClone(app.packageName)\n"
        "        }\n",
        "        if (FreezerCloneKey.isClone(app.packageName)) {\n"
        "            // 分身：直接在对应用户里启动，不经过系统「选主应用还是分身」的弹窗。\n"
        "            return@withContext FreezerCloneSupport.launchClone(app.packageName)\n"
        "        }\n"
        "        // 主应用：全屏启动时也走 shell 指定用户启动，避免系统弹出「主应用 / 分身」选择框。\n"
        "        if (fullscreen && hasShellAccess() && FreezerCloneSupport.launchMain(app.packageName)) {\n"
        "            return@withContext true\n"
        "        }\n",
        1,
    )],
)

# ---- 2) 分身状态查询缓存（减少 Shizuku 跨进程调用）
edits = [
    # 1) 分身应用信息：2 秒缓存，避免界面每次重组都走一遍 Shizuku 跨进程调用
    (
        "    /** 经 Shizuku 调 IPackageManager.getApplicationInfo(包名, flags, 用户)。 */\n"
        "    private fun appInfoAsUser(packageName: String, userId: Int): ApplicationInfo? = runCatching {\n",
        "    private val cloneInfoCache =\n"
        "        java.util.concurrent.ConcurrentHashMap<String, Pair<Long, ApplicationInfo?>>()\n"
        "\n"
        "    private fun invalidateCloneCache() = cloneInfoCache.clear()\n"
        "\n"
        "    private fun appInfoAsUser(packageName: String, userId: Int): ApplicationInfo? {\n"
        "        val cacheKey = \"$packageName#$userId\"\n"
        "        val now = android.os.SystemClock.elapsedRealtime()\n"
        "        cloneInfoCache[cacheKey]?.let { (time, info) ->\n"
        "            if (now - time < 2000L) return info\n"
        "        }\n"
        "        val info = queryAppInfoAsUser(packageName, userId)\n"
        "        cloneInfoCache[cacheKey] = now to info\n"
        "        return info\n"
        "    }\n"
        "\n"
        "    /** 经 Shizuku 调 IPackageManager.getApplicationInfo(包名, flags, 用户)。 */\n"
        "    private fun queryAppInfoAsUser(packageName: String, userId: Int): ApplicationInfo? = runCatching {\n",
        1,
    ),
    # 2) 等待状态变化时必须读最新值 不能读缓存
    (
        "    private fun waitForSuspended(context: Context, packageName: String, suspended: Boolean): Boolean {\n"
        "        repeat(8) {\n"
        "            if (isAppSuspended(context, packageName) == suspended) return true\n"
        "            Thread.sleep(60)\n"
        "        }\n"
        "        return isAppSuspended(context, packageName) == suspended\n"
        "    }\n",
        "    private fun waitForSuspended(context: Context, packageName: String, suspended: Boolean): Boolean {\n"
        "        repeat(8) {\n"
        "            invalidateCloneCache()\n"
        "            if (isAppSuspended(context, packageName) == suspended) return true\n"
        "            Thread.sleep(60)\n"
        "        }\n"
        "        invalidateCloneCache()\n"
        "        return isAppSuspended(context, packageName) == suspended\n"
        "    }\n",
        1,
    ),
    (
        "    private fun waitForState(context: Context, packageName: String, disabled: Boolean): Boolean {\n"
        "        repeat(8) {\n"
        "            if (isAppDisabled(context, packageName) == disabled) return true\n"
        "            Thread.sleep(60)\n"
        "        }\n"
        "        return isAppDisabled(context, packageName) == disabled\n"
        "    }\n",
        "    private fun waitForState(context: Context, packageName: String, disabled: Boolean): Boolean {\n"
        "        repeat(8) {\n"
        "            invalidateCloneCache()\n"
        "            if (isAppDisabled(context, packageName) == disabled) return true\n"
        "            Thread.sleep(60)\n"
        "        }\n"
        "        invalidateCloneCache()\n"
        "        return isAppDisabled(context, packageName) == disabled\n"
        "    }\n",
        1,
    ),
]


ok &= patch(BASE + "FreezerPrivilegedOps.kt", "queryAppInfoAsUser", edits)


# ---- 3) 无障碍前台跟踪：窗口变化事件合并间隔 200ms -> 1000ms，锁屏判定 500ms -> 2000ms（后台省电）
ok &= patch(
    "app/src/main/java/com/slideindex/app/service/SlideIndexAccessibilityForegroundTracker.kt",
    "WINDOWS_CHANGED_COALESCE_MS = 1000L",
    [
        ("        private const val WINDOWS_CHANGED_COALESCE_MS = 200L\n",
         "        private const val WINDOWS_CHANGED_COALESCE_MS = 1000L\n", 1),
        ("        private const val LOCK_SCREEN_WORK_TTL_MS = 500L\n",
         "        private const val LOCK_SCREEN_WORK_TTL_MS = 2000L\n", 1),
    ],
)

# ---- 4) 冰箱面板：去掉回到前台自动刷新 顶栏加手动刷新按钮
ok &= patch(
    BASE + "FreezerPanelContent.kt",
    "freezer_manual_refresh",
    [
        ("import androidx.compose.material.icons.filled.MoreVert\n",
         "import androidx.compose.material.icons.filled.MoreVert\nimport androidx.compose.material.icons.filled.Refresh\n", 1),
        ("            if (event == Lifecycle.Event.ON_RESUME) {\n"
         "                freezeStateRevision++\n"
         "            }\n",
         "            // freezer_manual_refresh：不再每次回到前台自动刷新，改由顶栏刷新按钮手动触发。\n"
         "            if (event == Lifecycle.Event.ON_RESUME && false) {\n"
         "                freezeStateRevision++\n"
         "            }\n", 1),
        ("                MiuixExpandableSearchIconAction(\n"
         "                    expanded = searchExpanded,\n",
         "                IconButton(\n"
         "                    onClick = {\n"
         "                        scope.launch {\n"
         "                            FreezerCloneSupport.syncCloneMembers(context, settingsRepository, force = true)\n"
         "                            freezeStateRevision++\n"
         "                        }\n"
         "                    }\n"
         "                ) {\n"
         "                    Icon(\n"
         "                        imageVector = Icons.Default.Refresh,\n"
         "                        contentDescription = \"刷新\",\n"
         "                        tint = MiuixTheme.colorScheme.onBackground\n"
         "                    )\n"
         "                }\n"
         "                MiuixExpandableSearchIconAction(\n"
         "                    expanded = searchExpanded,\n", 1),
    ],
)

# ---- 5) 冰箱浮窗背景：跟随主题色 只加透明度
ok &= patch(
    BASE + "FreezerOverlayWindow.kt",
    "surface.copy(alpha = 0.78f)",
    [
        ("                color = MaterialTheme.colorScheme.surface,\n"
         "                tonalElevation = 2.dp\n",
         "                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),\n"
         "                tonalElevation = 0.dp\n", 1),
    ],
)


# ---- 6) 触控板：高度下限放开（252 -> 170dp），整体深色，点顶部三点横条切换不透明度
SC = "app/src/main/java/com/slideindex/app/screencontrol/"
ok &= patch(
    SC + "ScreenControlPrefs.kt",
    "MIN_HEIGHT_DP = 170",
    [("    const val MIN_HEIGHT_DP = 252\n", "    const val MIN_HEIGHT_DP = 170\n", 1)],
)

ok &= patch(
    SC + "ScreenControlPanelView.kt",
    "ScreenControlStyle.cycle",
    [
        # 面板 / 圆球 / 触控区 底色改深色并带不透明度
        ("        setColor(Color.argb(if (blurEnabled) 165 else 248, 245, 247, 252))\n"
         "        setStroke((1f * density).roundToInt(), Color.argb(35, 0, 0, 0))\n",
         "        setColor(Color.argb(ScreenControlStyle.panelAlpha(context, blurEnabled), 10, 10, 12))\n"
         "        setStroke((1f * density).roundToInt(), Color.argb(60, 255, 255, 255))\n", 1),
        ("        setColor(Color.argb(if (blurEnabled) 130 else 220, 235, 240, 248))\n",
         "        setColor(Color.argb(if (blurEnabled) 150 else 230, 24, 24, 28))\n", 1),
        ("        setColor(Color.argb(if (blurEnabled) 60 else 185, 255, 255, 255))\n",
         "        setColor(Color.argb(ScreenControlStyle.padAlpha(context, blurEnabled), 44, 44, 50))\n", 1),
        ("        setStroke((0.85f * density).roundToInt(), Color.argb(38, 0, 0, 0))\n",
         "        setStroke((0.85f * density).roundToInt(), Color.argb(50, 255, 255, 255))\n", 1),
        # 模糊底的着色
        ("            tintColor = Color.argb(170, 248, 250, 255),\n",
         "            tintColor = Color.argb(ScreenControlStyle.panelAlpha(context, true), 10, 10, 12),\n", 1),
        ("                tintColor = Color.argb(120, 235, 244, 255),\n",
         "                tintColor = Color.argb(130, 24, 24, 28),\n", 1),
        # 按键底色 描边
        ("                    else -> withAlpha(themeColors.cardBackground, 180)\n",
         "                    else -> Color.argb(46, 255, 255, 255)\n", 1),
        ("                    else -> Color.argb(32, 0, 0, 0)\n",
         "                    else -> Color.argb(46, 255, 255, 255)\n", 1),
        # 图标 三点横条 底部横条 改浅色
        ("            color = Color.BLACK\n"
         "            style = Paint.Style.STROKE\n"
         "            strokeWidth = 1.35f * density\n",
         "            color = Color.WHITE\n"
         "            style = Paint.Style.STROKE\n"
         "            strokeWidth = 1.35f * density\n", 1),
        ("                color = Color.argb(225, 28, 30, 36)\n",
         "                color = Color.argb(225, 230, 232, 238)\n", 1),
        ("                color = withAlpha(themeColors.textPrimary, if (armed) 220 else 165)\n",
         "                color = withAlpha(Color.WHITE, if (armed) 220 else 165)\n", 1),
        ("        color = Color.argb(135, 255, 255, 255)\n",
         "        color = Color.argb(60, 255, 255, 255)\n", 1),
        # 点一下顶部三点横条：切换不透明度
        ("    fun setMinimized(minimized: Boolean) {\n",
         "    private fun cycleOpacity() {\n"
         "        val percent = ScreenControlStyle.cycle(context)\n"
         "        applyPanelBackground()\n"
         "        pad.background = padBackground()\n"
         "        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)\n"
         "        android.widget.Toast.makeText(context, \"不透明度 $percent%\", android.widget.Toast.LENGTH_SHORT).show()\n"
         "    }\n"
         "\n"
         "    fun setMinimized(minimized: Boolean) {\n", 1),
        ("        private var dragging = false\n"
         "\n"
         "        override fun onTouch(view: View, event: MotionEvent): Boolean {\n"
         "            when (event.actionMasked) {\n"
         "                MotionEvent.ACTION_DOWN -> {\n"
         "                    lastRawX = event.rawX\n"
         "                    lastRawY = event.rawY\n"
         "                    dragging = true\n"
         "                    return true\n"
         "                }\n",
         "        private var dragging = false\n"
         "        private var downRawX = 0f\n"
         "        private var downRawY = 0f\n"
         "        private var movedFar = false\n"
         "\n"
         "        override fun onTouch(view: View, event: MotionEvent): Boolean {\n"
         "            when (event.actionMasked) {\n"
         "                MotionEvent.ACTION_DOWN -> {\n"
         "                    lastRawX = event.rawX\n"
         "                    lastRawY = event.rawY\n"
         "                    downRawX = event.rawX\n"
         "                    downRawY = event.rawY\n"
         "                    movedFar = false\n"
         "                    dragging = true\n"
         "                    return true\n"
         "                }\n", 1),
        ("                    if (dx != 0f || dy != 0f) listener.onMovePanel(dx, dy)\n",
         "                    if (hypot(event.rawX - downRawX, event.rawY - downRawY) > 8f * density) movedFar = true\n"
         "                    if (dx != 0f || dy != 0f) listener.onMovePanel(dx, dy)\n", 1),
        ("                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {\n"
         "                    if (dragging) listener.onPanelMoveFinished()\n"
         "                    dragging = false\n"
         "                    return true\n"
         "                }\n",
         "                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {\n"
         "                    if (dragging) listener.onPanelMoveFinished()\n"
         "                    if (event.actionMasked == MotionEvent.ACTION_UP && !movedFar) cycleOpacity()\n"
         "                    dragging = false\n"
         "                    return true\n"
         "                }\n", 1),
    ],
)


# ---- 7) 双击背部：不再启动检测器（不注册传感器，零耗电）。摇一摇的入口还没读到，下一批处理。
ok &= patch(
    "app/src/main/java/com/slideindex/app/backtap/BackTapGestureHost.kt",
    "双击背部功能已禁用",
    [(
        "        val shouldRun = backTap.enabled && settings.serviceEnabled\n",
        "        // 双击背部功能已禁用：不再注册传感器。\n"
        "        val shouldRun = false\n",
        1,
    )],
)



# ---- 8) 冰箱页启动的应用排到最前面，冻结后回到原位
ok &= patch(
    BASE + "FreezerOperations.kt",
    "FreezerLaunchOrder.mark",
    [(
        "    ): Boolean = withContext(Dispatchers.IO) {\n"
        "        when (val state = stateOf(context, app.packageName)) {\n",
        "    ): Boolean = withContext(Dispatchers.IO) {\n"
        "        // 记下启动时间：冰箱列表里它会排到最前面，冻结后回到原位。\n"
        "        FreezerLaunchOrder.mark(context, app.packageName)\n"
        "        when (val state = stateOf(context, app.packageName)) {\n",
        1,
    )],
)


def patch_grid_order():
    path = BASE + "FreezerGridUi.kt"
    text, crlf = load(path)
    if "FreezerLaunchOrder.arrange" in text:
        print("已打过 跳过:", path, "FreezerLaunchOrder.arrange")
        return True
    patched = (
        "        }.sortedByDescending { app -> FreezerPinStore.isPinned(context, app.packageName) }\n"
        "    }\n"
    )
    original = (
        "    val filteredApps = remember(memberApps, searchQuery) {\n"
        "        val query = searchQuery.trim().lowercase()\n"
        "        memberApps.filter { app ->\n"
        "            query.isBlank() ||\n"
        "                app.label.contains(query, ignoreCase = true) ||\n"
        "                app.packageName.contains(query, ignoreCase = true) ||\n"
        "                app.pinyinKey.contains(query)\n"
        "        }\n"
        "    }\n"
    )
    if text.count(patched) == 1:
        text = text.replace(patched, "        }.let { FreezerLaunchOrder.arrange(context, it) }\n    }\n")
    elif text.count(original) == 1:
        text = text.replace(original, original
            .replace("remember(memberApps, searchQuery)", "remember(memberApps, searchQuery, freezeStateRevision)")
            .replace("        }\n    }\n", "        }.let { FreezerLaunchOrder.arrange(context, it) }\n    }\n"))
    else:
        print("补丁失败 " + path + ": 找不到 filteredApps 的排序位置")
        return False
    save(path, text, crlf)
    print("已修改", path)
    return True


ok &= patch_grid_order()

if not ok:
    sys.exit(1)
print("补丁完成")
